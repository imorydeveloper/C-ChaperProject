﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShippingandHandling
{
    public partial class frmShippingandHandling : Form
    {
        public frmShippingandHandling()
        {
            InitializeComponent();
        }

        private void btnCalculateGradeTotal_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == (char)Keys.Enter)
            {

            }
        }

        private void btnExit_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == (char)Keys.Escape)
            {
                
            }
        }

        
    }
}
