﻿namespace StudentPopulation
{
    partial class frmStudentPopulation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtNumberOfStudentsToday = new System.Windows.Forms.TextBox();
            this.txtAnnualOfGrowthrate = new System.Windows.Forms.TextBox();
            this.txtNumberOfyears = new System.Windows.Forms.TextBox();
            this.txtProjectNumberofStudents = new System.Windows.Forms.TextBox();
            this.btnPrjectStudentPopulation = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(62, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(351, 35);
            this.label1.TabIndex = 0;
            this.label1.Text = "&Number of Students Today";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(62, 143);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(351, 36);
            this.label2.TabIndex = 1;
            this.label2.Text = "Annual of growth rate";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(67, 222);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(346, 38);
            this.label3.TabIndex = 2;
            this.label3.Text = "Number of years";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(68, 300);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(345, 36);
            this.label4.TabIndex = 3;
            this.label4.Text = "Projected number of students";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtNumberOfStudentsToday
            // 
            this.txtNumberOfStudentsToday.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNumberOfStudentsToday.Location = new System.Drawing.Point(455, 65);
            this.txtNumberOfStudentsToday.Multiline = true;
            this.txtNumberOfStudentsToday.Name = "txtNumberOfStudentsToday";
            this.txtNumberOfStudentsToday.Size = new System.Drawing.Size(238, 35);
            this.txtNumberOfStudentsToday.TabIndex = 1;
            this.txtNumberOfStudentsToday.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtAnnualOfGrowthrate
            // 
            this.txtAnnualOfGrowthrate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAnnualOfGrowthrate.Location = new System.Drawing.Point(455, 143);
            this.txtAnnualOfGrowthrate.Multiline = true;
            this.txtAnnualOfGrowthrate.Name = "txtAnnualOfGrowthrate";
            this.txtAnnualOfGrowthrate.Size = new System.Drawing.Size(238, 36);
            this.txtAnnualOfGrowthrate.TabIndex = 2;
            this.txtAnnualOfGrowthrate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtNumberOfyears
            // 
            this.txtNumberOfyears.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNumberOfyears.Location = new System.Drawing.Point(455, 222);
            this.txtNumberOfyears.Multiline = true;
            this.txtNumberOfyears.Name = "txtNumberOfyears";
            this.txtNumberOfyears.Size = new System.Drawing.Size(238, 38);
            this.txtNumberOfyears.TabIndex = 3;
            this.txtNumberOfyears.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtProjectNumberofStudents
            // 
            this.txtProjectNumberofStudents.BackColor = System.Drawing.SystemColors.ControlDark;
            this.txtProjectNumberofStudents.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtProjectNumberofStudents.Location = new System.Drawing.Point(455, 300);
            this.txtProjectNumberofStudents.Multiline = true;
            this.txtProjectNumberofStudents.Name = "txtProjectNumberofStudents";
            this.txtProjectNumberofStudents.ReadOnly = true;
            this.txtProjectNumberofStudents.Size = new System.Drawing.Size(238, 36);
            this.txtProjectNumberofStudents.TabIndex = 5;
            this.txtProjectNumberofStudents.TabStop = false;
            this.txtProjectNumberofStudents.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnPrjectStudentPopulation
            // 
            this.btnPrjectStudentPopulation.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnPrjectStudentPopulation.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrjectStudentPopulation.Location = new System.Drawing.Point(99, 386);
            this.btnPrjectStudentPopulation.Name = "btnPrjectStudentPopulation";
            this.btnPrjectStudentPopulation.Size = new System.Drawing.Size(246, 81);
            this.btnPrjectStudentPopulation.TabIndex = 4;
            this.btnPrjectStudentPopulation.Text = "&Project Student Population";
            this.btnPrjectStudentPopulation.UseVisualStyleBackColor = false;
            this.btnPrjectStudentPopulation.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnPrjectStudentPopulation_KeyPress);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(455, 386);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(238, 81);
            this.btnExit.TabIndex = 5;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnExit_KeyPress);
            // 
            // frmStudentPopulation
            // 
            this.AcceptButton = this.btnPrjectStudentPopulation;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(757, 509);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnPrjectStudentPopulation);
            this.Controls.Add(this.txtProjectNumberofStudents);
            this.Controls.Add(this.txtNumberOfyears);
            this.Controls.Add(this.txtAnnualOfGrowthrate);
            this.Controls.Add(this.txtNumberOfStudentsToday);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "frmStudentPopulation";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Student Population";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtNumberOfStudentsToday;
        private System.Windows.Forms.TextBox txtAnnualOfGrowthrate;
        private System.Windows.Forms.TextBox txtNumberOfyears;
        private System.Windows.Forms.TextBox txtProjectNumberofStudents;
        private System.Windows.Forms.Button btnPrjectStudentPopulation;
        private System.Windows.Forms.Button btnExit;
    }
}

