﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TelephoneNumbers
{
    public partial class frmTelephoneNumbers : Form
    {
        public frmTelephoneNumbers()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnConverToNumericOnly_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == (char)Keys.Enter)
            {

            }
        }

        private void btnExit_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == (char)Keys.Escape)
            {

            }
        }

        private void btnConverToNumericOnly_Click(object sender, EventArgs e)
        {
            string inputString = txtAlphanumericNumber.Text;
            string convertString = "";

            for (int i = 0; i < inputString.Length; i++)
            {
               
                string ch = inputString.Substring(i, 1);
                string convertChar = "";

                switch (ch.ToUpper())
                {
                    case "A":
                    case "B":
                    case "C":
                        convertChar = "2";
                        break;
                    case "D":
                    case "E":
                    case "F":
                        convertChar = "3";
                        break;
                    case "G":
                    case "H":
                    case "I":
                        convertChar = "4";
                        break;
                    case "J":
                    case "K":
                    case "L":
                        convertChar = "5";
                        break;
                    case "M":
                    case "N":
                    case "O":
                        convertChar = "6";
                        break;
                    case "P":
                    case "Q":
                    case "R":
                    case "S":
                        convertChar = "7";
                        break;
                    case "T":
                    case "U":
                    case "V":
                        convertChar = "8";
                        break;
                    case "W":
                    case "X":
                    case "Y":
                    case "Z":
                        convertChar = "9";
                        break;
                    default:
                        convertChar = ch;
                        break;
                }

                convertString += convertChar;
            }

            txtNumericOnly.Text = convertString;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtAlphanumericNumber_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
