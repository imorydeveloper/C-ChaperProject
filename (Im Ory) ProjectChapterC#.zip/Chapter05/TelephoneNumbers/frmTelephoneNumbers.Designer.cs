﻿namespace TelephoneNumbers
{
    partial class frmTelephoneNumbers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtAlphanumericNumber = new System.Windows.Forms.TextBox();
            this.txtNumericOnly = new System.Windows.Forms.TextBox();
            this.btnConverToNumericOnly = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(36, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(270, 33);
            this.label1.TabIndex = 0;
            this.label1.Text = "&Alphanumeric Number";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(36, 138);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(270, 37);
            this.label2.TabIndex = 8;
            this.label2.Text = "Numeric Only";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtAlphanumericNumber
            // 
            this.txtAlphanumericNumber.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAlphanumericNumber.Location = new System.Drawing.Point(351, 51);
            this.txtAlphanumericNumber.Multiline = true;
            this.txtAlphanumericNumber.Name = "txtAlphanumericNumber";
            this.txtAlphanumericNumber.Size = new System.Drawing.Size(262, 45);
            this.txtAlphanumericNumber.TabIndex = 1;
            this.txtAlphanumericNumber.TextChanged += new System.EventHandler(this.txtAlphanumericNumber_TextChanged);
            // 
            // txtNumericOnly
            // 
            this.txtNumericOnly.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.txtNumericOnly.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNumericOnly.Location = new System.Drawing.Point(351, 131);
            this.txtNumericOnly.Multiline = true;
            this.txtNumericOnly.Name = "txtNumericOnly";
            this.txtNumericOnly.ReadOnly = true;
            this.txtNumericOnly.Size = new System.Drawing.Size(262, 44);
            this.txtNumericOnly.TabIndex = 9;
            this.txtNumericOnly.TabStop = false;
            // 
            // btnConverToNumericOnly
            // 
            this.btnConverToNumericOnly.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnConverToNumericOnly.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConverToNumericOnly.Location = new System.Drawing.Point(108, 267);
            this.btnConverToNumericOnly.Name = "btnConverToNumericOnly";
            this.btnConverToNumericOnly.Size = new System.Drawing.Size(158, 100);
            this.btnConverToNumericOnly.TabIndex = 2;
            this.btnConverToNumericOnly.Text = "&Convert to Numeric Only";
            this.btnConverToNumericOnly.UseVisualStyleBackColor = false;
            this.btnConverToNumericOnly.Click += new System.EventHandler(this.btnConverToNumericOnly_Click);
            this.btnConverToNumericOnly.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnConverToNumericOnly_KeyPress);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(384, 267);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(154, 100);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            this.btnExit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnExit_KeyPress);
            // 
            // frmTelephoneNumbers
            // 
            this.AcceptButton = this.btnConverToNumericOnly;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(683, 472);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnConverToNumericOnly);
            this.Controls.Add(this.txtNumericOnly);
            this.Controls.Add(this.txtAlphanumericNumber);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "frmTelephoneNumbers";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Telephone Numbers";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtAlphanumericNumber;
        private System.Windows.Forms.TextBox txtNumericOnly;
        private System.Windows.Forms.Button btnConverToNumericOnly;
        private System.Windows.Forms.Button btnExit;
    }
}

