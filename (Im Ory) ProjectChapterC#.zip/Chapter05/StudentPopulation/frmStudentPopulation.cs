﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentPopulation
{
    public partial class frmStudentPopulation : Form
    {
        public frmStudentPopulation()
        {
            InitializeComponent();
        }

        private void btnPrjectStudentPopulation_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == (char)Keys.Enter)
            {

            }
        }

        private void btnExit_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == (char)Keys.Escape)
            {

            }
        }

        private void btnPrjectStudentPopulation_Click(object sender, EventArgs e)
        {
            
            double numberOfStudentsToday = Convert.ToDouble(txtNumberOfStudentsToday.Text);
            double annualGrowthRate = Convert.ToDouble(txtAnnualOfGrowthRate.Text);
            int numberOfYears = Convert.ToInt32(txtNumberOfyears.Text);
            double projectedNumbersofStudent = 0.0;
            int i = 1;
            double result = 1.0;
            double rate = annualGrowthRate + 1;

            while (i <= numberOfYears)
            {
                result*= rate;
                i++;
            }

            projectedNumbersofStudent = numberOfStudentsToday * result;
            txtNumberOfStudentsToday.Text = numberOfStudentsToday.ToString();
            txtAnnualOfGrowthRate.Text = annualGrowthRate.ToString();
            txtNumberOfyears.Text = numberOfYears.ToString();
            txtProjectNumberofStudents.Text = string.Format("{0:N0}", projectedNumbersofStudent);

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
