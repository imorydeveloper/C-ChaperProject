﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InvoiceTotal1
{
    public partial class frmInvoiceTotal1 : Form
    {
        public frmInvoiceTotal1()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnCalculate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == (char)Keys.Enter)
            {

            }
        }

        private void btnExit_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == (char)Keys.Escape)
            {

            }
        }

        private void frmInvoiceTotal1_Load(object sender, EventArgs e)
        {

        }

        private void txtSubtotal_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            string customerType = txtCustomerType.Text;
            decimal subTotal = Convert.ToDecimal(txtSubtotal.Text);
            decimal discountPercent = 0;

            if (customerType == "R" || customerType == "r")
            {
                if (subTotal >= 250 && subTotal < 500)
                {
                    discountPercent = .25m;
                }
                else if (subTotal >= 500)
                {
                    discountPercent = .30m;
                }
            } else if (customerType == "C" || customerType == "c")
            {
                discountPercent = .20m;

            } else if (customerType == "T" || customerType == "t")
            {
                if (subTotal < 500)
                {
                    discountPercent = .40m;
                }
                else if (subTotal >= 500) {
                    discountPercent = .50m;
                }

            }

            decimal discountAmount = subTotal * discountPercent;
            decimal invoiceTotal = subTotal - discountAmount;

            lbDiscountPercent.Text = discountPercent.ToString("p1");
            lbDiscountAmount.Text = discountAmount.ToString("c");
            lbTotal.Text = invoiceTotal.ToString("c");

            txtCustomerType.Focus();

        }
    }
}
