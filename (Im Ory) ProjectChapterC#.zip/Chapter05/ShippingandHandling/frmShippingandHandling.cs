﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShippingandHandling
{
    public partial class frmShippingandHandling : Form
    {
        public frmShippingandHandling()
        {
            InitializeComponent();
        }

        private void btnCalculateGradeTotal_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == (char)Keys.Enter)
            {

            }
        }

        private void btnExit_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == (char)Keys.Escape)
            {
                
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCalculateGradeTotal_Click(object sender, EventArgs e)
        {
            
            decimal orderTotal = decimal.Parse(txtOrderTotal.Text);
            string customerType = txtCustomerType.Text;
            decimal shippingCosts = 0.00m;
            
    

            if(customerType == "N")
            {
                if(orderTotal >= 0.00m && orderTotal <= 25.00m) 

                    shippingCosts = 5.00m;
                    
                else if(orderTotal >= 25.01m && orderTotal <= 500.00m)
                
                    shippingCosts = 8.00m;
                   
                else if(orderTotal >=500.01m && orderTotal <= 1000.00m)
                
                    shippingCosts = 10.00m;
                    
                else if(orderTotal >= 1000.01m && orderTotal <= 5000.00m)

                    shippingCosts = 15.00m;
            
                else 
                    shippingCosts = 20.00m;

            }
            else if(customerType == "P")
                shippingCosts = 0.00m;
            else
                MessageBox.Show("Invalid!, Please input P or N customertype.");
            

            decimal salesTax = (orderTotal + shippingCosts) * 0.07m;
            decimal grandTotal = orderTotal + shippingCosts + salesTax;
            txtShippingCosts.Text = string.Format("${0:N2}", shippingCosts);
            txtSalesTax.Text = string.Format("${0:N2}", salesTax);
            txtGradeTotal.Text = string.Format("${0:N2}", grandTotal);
        }
    }
}
